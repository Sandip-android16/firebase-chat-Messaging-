package com.example.firebasemessa.model;



public class Message{
    public String idSender;
    public String idReceiver;
    public String text;
    public long timestamp;
}